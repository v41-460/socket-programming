# Socket Programming

To run the program, first you need to start the server:

	make run-server

Then you open another terminal (MacOS) or command line (Windows) to start the client:

	make run-client

You can open multiple terminals or command lines to run multiple clients at the same time.

To clean up the database cache:

	make clean
