# constants.py
# Contains the constants variables shared by the server and client

HOST = '127.0.0.1'
PORT = 65432

BUFFER_SIZE = 1024